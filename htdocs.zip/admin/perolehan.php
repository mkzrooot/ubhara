<div class="text-right"><button id="save-img" class="btn btn-success">Simpan Grafik</button></div>
<div style="font-size:18px;">
   <canvas id="canvas"></canvas>
</div>
